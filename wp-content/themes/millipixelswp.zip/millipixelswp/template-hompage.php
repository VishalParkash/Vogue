
<?php /* Template Name: Homepage Template*/?>
<?php
get_header();
?>
<!-- Section Custom Product tab -->
<!-- <section>Home Page Inner Section</section> -->





<?php

// check if the repeater field has rows of data
if( have_rows('section') ):

 	// loop through the rows of data
    while ( have_rows('section') ) : the_row();

        // display a sub field value
        // the_sub_field('section_type');
        // the_sub_field('section_type');
        $sub_value = get_sub_field('section_type');
        

        if($sub_value == "Full Width Post") {

            // code 
        /*
        $post = get_sub_field_object('select_post');
        echo "<pre>";
        print_r($post['value']);
        echo "</pre>";

        */

        
        
        
        $post = get_sub_field_object('select_post');

        $imageURL =  get_the_post_thumbnail_url($post['value']->ID);
        $postTitle =  $post['value']->post_title;
        $category = get_the_category($post['value']->ID);
        $categoryName = $category[0]->name;
        $user_nickname = get_the_author_meta('nickname',$post['value']->post_author);
        $post_date = $post['value']->post_date;
        $postDate = strtoupper(date("d F Y", strtotime($post_date)));
        // echo date_format($date,"Y/m/d H:i:s");
      


        

        

        

            // code 
?>
    <section class="full-post">
      <div class="container">
        <h2 class="secHeading">
          <span>In Vogue</span>
        </h2>

        <div class="row">
          <div class="col-sm-12">
            <div class="post-img">
              <a href="javascript:void(0)">
                <div class="img-wrap">
                  <img src="<?php echo $imageURL; ?>" alt="full-post-img">
                </div>

                <div class="img-text">
                    <div class="img-caption">
                        <!-- <h6>Fashion</h6> -->
                        <h6><?php echo $categoryName; ?></h6>
                        <!-- <h3>Alia Bhatt on why father Mahesh Bhatt celebrated when Shaandaar failed at the box office</h3> -->
                        <h3><?php echo $postTitle; ?></h3>
                        <div class="caption-detail">
                          <span class="author"> By  <?php echo $user_nickname; ?> </span>
                          <span class="time"><?php echo $postDate; ?></span>
                        </div>
                      </div>
                </div>

              </a>
            </div>
          </div>
        </div>
      </div>
    </section>

<?php
        }
        elseif($sub_value == "Grid Post") {
            // die('hehre');
?>

    <section class="all-post text-style ">
      <div class="container">
        <h2 class="secHeading">
            <span>Fashion</span>
          </h2>

        <div class="row">
          <div class="col-lg-6">
            <div class="sticky-post">
              <a href="javascript:void(0)">
                  <img src="<?php echo get_stylesheet_directory_uri()?>/images/Kendell-Jenner.jpg" alt="">

                  <div class="post-content">
                  <div class="img-caption">
                    <h6>Fashion</h6>
                    <h3> Exclusive: Giambattista Valli on his collaboration with H&amp;M </h3>
                    <span class="author ">
                      By  Naheed Driver 
                    </span>
                  </div>
                </div>
              </a>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="posts">

                <div class="singlePostItm singlePostItmMob">
                    <a href="javascript:void(0);">
                      <div class="singlePostItmImg">
                        <img src="<?php echo get_stylesheet_directory_uri()?>/images/renPost1.jpg" alt="renPost1">
                      </div>
                      <div class="singlePostItmTxt">
                        <span class="postTag">Fashion</span>
                        <h3>
                          Shunali Shroff’s new novel is a witty take on marriages
                          and love among Mumbai’s rich and famous
                        </h3>
                        <span class="postBy">BY MAANYA SACHDEVA</span>
                        <!-- <span class="postDate">16 OCTOBER 2019</span> -->
                      </div>
                    </a>
                  </div>

                  <div class="singlePostItm singlePostItmMob">
                      <a href="javascript:void(0);">
                        <div class="singlePostItmImg">
                          <img src="<?php echo get_stylesheet_directory_uri()?>/images/renPost2.jpg" alt="renPost2">
                        </div>
                        <div class="singlePostItmTxt">
                          <span class="postTag">Fashion</span>
                          <h3>
                            Hermione Granger fans, you'll love these Emma
                            Watson-approved feminist books
                          </h3>
                          <span class="postBy">BY Susan Devaney</span>
                          <!-- <span class="postDate">5 November 2019</span> -->
                        </div>
                      </a>
                    </div>

                    <div class="singlePostItm singlePostItmMob">
                        <a href="javascript:void(0);">
                          <div class="singlePostItmImg">
                            <img src="<?php echo get_stylesheet_directory_uri()?>/images/renPost1.jpg" alt="renPost1">
                          </div>
                          <div class="singlePostItmTxt">
                            <span class="postTag">Fashion</span>
                            <h3>
                              Shunali Shroff’s new novel is a witty take on marriages
                              and love among Mumbai’s rich and famous
                            </h3>
                            <span class="postBy">BY MAANYA SACHDEVA</span>
                            <!-- <span class="postDate">16 OCTOBER 2019</span> -->
                          </div>
                        </a>
                      </div>

                      <div class="singlePostItm singlePostItmMob">
                          <a href="javascript:void(0);">
                            <div class="singlePostItmImg">
                              <img src="<?php echo get_stylesheet_directory_uri()?>/images/renPost2.jpg" alt="renPost2">
                            </div>
                            <div class="singlePostItmTxt">
                              <span class="postTag">Fashion</span>
                              <h3>
                                Hermione Granger fans, you'll love these Emma
                                Watson-approved feminist books
                              </h3>
                              <span class="postBy">BY Susan Devaney</span>
                              <!-- <span class="postDate">5 November 2019</span> -->
                            </div>
                          </a>
                        </div>
            </div>
          </div>
        </div>
      </div>
    </section>

<?php
        }
        elseif($sub_value == "Post Carousel") {
            echo "Post Carousel";
        }
        
        
        

    endwhile;

else :

    // no rows found

endif;

?>



<?php
get_footer();
?>
