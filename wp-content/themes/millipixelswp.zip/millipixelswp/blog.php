
<?php /* Template Name: Blog Template*/?>
<?php
get_header();
?>
<!-- Section Custom Product tab -->
<section>Home Page Inner Section</section>
<?php
get_footer();
?>
