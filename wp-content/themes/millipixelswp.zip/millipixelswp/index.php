<?php
get_header(); 
?>
<div>Vouge</div>
<?php get_footer(); ?>
